// license-header java merge-point
package org.andromda.cartridges.jsf.tests.finalstates.hyperlinked;

/**
 * @see org.andromda.cartridges.jsf.tests.finalstates.hyperlinked.Controller
 */
public class ControllerImpl
    extends Controller
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -8195982769161260913L;
    
}