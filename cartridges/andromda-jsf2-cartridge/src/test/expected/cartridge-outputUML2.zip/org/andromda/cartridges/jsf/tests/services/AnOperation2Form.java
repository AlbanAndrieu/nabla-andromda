// license-header java merge-point
package org.andromda.cartridges.jsf.tests.services;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>anOperation2</code> method, which is located on the
 * <code>org.andromda.cartridges.jsf.tests.services.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.jsf.tests.services.Controller#anOperation2(java.lang.String one, int two, java.lang.String three)
 */
public interface AnOperation2Form
{
    /**
     * Gets the ValueChangeEvent (if any) that is associated with this form.
     * 
     * @return the faces ValueChangeEvent associated to this form.
     */
    public javax.faces.event.ValueChangeEvent getValueChangeEvent();
    
    /**
     * Gets the ActionEvent (if any) that is associated with this form.
     * 
     * @return the faces ActionEvent associated to this form.
     */
    public javax.faces.event.ActionEvent getActionEvent();
    
    /**
     * Sets the event (if any) that is associated with this form.
     * 
     * @param event the faces event to associate to this form.
     */
    public void setEvent(javax.faces.event.FacesEvent event);
    
    /**
     * 
     */
    public java.lang.String getOne();

    /**
     * 
     */
    public void setOne(java.lang.String one);

    /**
     * 
     */
    public int getTwo();

    /**
     * 
     */
    public void setTwo(int two);

    /**
     * 
     */
    public java.lang.String getThree();

    /**
     * 
     */
    public void setThree(java.lang.String three);

}
