// license-header java merge-point
package org.andromda.cartridges.jsf.tests.constraints.exceptions.validtarget;

/**
 * @see org.andromda.cartridges.jsf.tests.constraints.exceptions.validtarget.Controller
 */
public class ControllerImpl
    extends Controller
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -9047889013777861952L;
    
}