// license-header java merge-point
package org.andromda.cartridges.jsf.tests.constraints.decisions.badtarget;

/**
 * @see org.andromda.cartridges.jsf.tests.constraints.decisions.badtarget.Controller
 */
public class ControllerImpl
    extends Controller
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -5336186575585643554L;
    
    /**
     * @see org.andromda.cartridges.jsf.tests.constraints.decisions.badtarget.Controller#thisOperationReturnsSomething()
     */
    @Override
    public java.lang.Object thisOperationReturnsSomething()
    {
        return null;
    }
    
}