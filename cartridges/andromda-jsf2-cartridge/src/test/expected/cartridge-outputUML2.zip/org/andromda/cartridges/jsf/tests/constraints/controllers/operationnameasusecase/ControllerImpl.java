// license-header java merge-point
package org.andromda.cartridges.jsf.tests.constraints.controllers.operationnameasusecase;

/**
 * @see org.andromda.cartridges.jsf.tests.constraints.controllers.operationnameasusecase.Controller
 */
public class ControllerImpl
    extends Controller
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 5338341630932901494L;
    
    /**
     * @see org.andromda.cartridges.jsf.tests.constraints.controllers.operationnameasusecase.Controller#OperationNameAsUseCase()
     */
    @Override
    public void OperationNameAsUseCase()
    {
    }
    
}