// license-header java merge-point
package org.andromda.cartridges.jsf.tests.tables.tablelink;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>loadTableData</code> method, which is located on the
 * <code>org.andromda.cartridges.jsf.tests.tables.tablelink.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.jsf.tests.tables.tablelink.Controller#loadTableData(java.util.Collection tableDatas, java.lang.String[] multiboxThings)
 */
public interface LoadTableDataForm
{
    /**
     * Gets the ValueChangeEvent (if any) that is associated with this form.
     * 
     * @return the faces ValueChangeEvent associated to this form.
     */
    public javax.faces.event.ValueChangeEvent getValueChangeEvent();
    
    /**
     * Gets the ActionEvent (if any) that is associated with this form.
     * 
     * @return the faces ActionEvent associated to this form.
     */
    public javax.faces.event.ActionEvent getActionEvent();
    
    /**
     * Sets the event (if any) that is associated with this form.
     * 
     * @param event the faces event to associate to this form.
     */
    public void setEvent(javax.faces.event.FacesEvent event);
    
    /**
     * 
     */
    public java.util.Collection getTableDatas();

    /**
     * 
     */
    public void setTableDatas(java.util.Collection tableDatas);

    /**
     * 
     */
    public java.lang.String[] getMultiboxThings();

    /**
     * 
     */
    public void setMultiboxThings(java.lang.String[] multiboxThings);

}
