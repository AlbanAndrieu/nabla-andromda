// license-header java merge-point
package org.andromda.cartridges.jsf.tests.formfields;

/**
 * @see org.andromda.cartridges.jsf.tests.formfields.Controller
 */
public class ControllerImpl
    extends Controller
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -494789178181811700L;
    
    /**
     * @see org.andromda.cartridges.jsf.tests.formfields.Controller#someOperation(java.util.Date date, int number, java.util.Collection collections, java.lang.String selectable, java.io.File file, java.lang.Integer integerClass, java.util.Set setClasses, java.util.Map mapClass, java.lang.Boolean booleanClass, boolean bool, java.lang.Float floatClass)
     */
    @Override
    public void someOperation(SomeOperationForm form)
    {
        // populating the table with a dummy list
        form.setCollections(collections);
        form.setSelectableValueList(new Object[] {"selectable-1", "selectable-2", "selectable-3", "selectable-4", "selectable-5"});
        form.setSelectableLabelList(form.getSelectableValueList());
        // populating the table with a dummy list
        form.setSetClasses(setClasses);
    }
    
    /**
     * @see org.andromda.cartridges.jsf.tests.formfields.Controller#anotherOperation(java.lang.String notused, int unusedNumber)
     */
    @Override
    public void anotherOperation(AnotherOperationForm form)
    {
    }
    
}