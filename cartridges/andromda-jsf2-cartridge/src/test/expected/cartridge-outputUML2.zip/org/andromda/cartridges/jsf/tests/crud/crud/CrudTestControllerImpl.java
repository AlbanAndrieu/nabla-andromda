// license-header java merge-point
package org.andromda.cartridges.jsf.tests.crud.crud;

/**
 * @see org.andromda.cartridges.jsf.tests.crud.crud.CrudTestController
 */
public class CrudTestControllerImpl
    extends CrudTestController
    implements java.io.Serializable
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 4913831644145054351L;
    
    
}
