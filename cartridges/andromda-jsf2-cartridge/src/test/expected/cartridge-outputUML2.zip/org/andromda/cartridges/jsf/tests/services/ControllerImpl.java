// license-header java merge-point
package org.andromda.cartridges.jsf.tests.services;

/**
 * @see org.andromda.cartridges.jsf.tests.services.Controller
 */
public class ControllerImpl
    extends Controller
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -2624436590850183758L;
    
    /**
     * @see org.andromda.cartridges.jsf.tests.services.Controller#crapmeout()
     */
    @Override
    public void crapmeout()
    {
    }
    
    /**
     * @see org.andromda.cartridges.jsf.tests.services.Controller#anOperation(java.lang.String one)
     */
    @Override
    public void anOperation(AnOperationForm form)
    {
    }
    
    /**
     * @see org.andromda.cartridges.jsf.tests.services.Controller#anOperation1(java.lang.String one, int two)
     */
    @Override
    public void anOperation1(AnOperation1Form form)
    {
    }
    
    /**
     * @see org.andromda.cartridges.jsf.tests.services.Controller#anOperation2(java.lang.String one, int two, java.lang.String three)
     */
    @Override
    public void anOperation2(AnOperation2Form form)
    {
    }
    
}