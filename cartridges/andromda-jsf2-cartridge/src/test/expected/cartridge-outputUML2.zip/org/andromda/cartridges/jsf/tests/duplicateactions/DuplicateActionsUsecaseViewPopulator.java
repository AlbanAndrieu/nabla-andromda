package org.andromda.cartridges.jsf.tests.duplicateactions;

/**
 * Provides the ability to populate any view in the DuplicateActions usecase
 */
public final class DuplicateActionsUsecaseViewPopulator
{
    /**
     * Attempts to populate the current view using the appropriate view populator.
     *
     * @param facesContext the current faces context.
     * @param form the form to pass to the populator.
     */
    public static void populateFormAndViewVariables(final javax.faces.context.FacesContext facesContext, Object form)
    {
        populateFormAndViewVariables(facesContext, form, null);
    }

    /**
     * Populates the view using the appropriate view populator.
     *
     * @param facesContext the current faces context.
     * @param form the form to pass to the populator.
     * @param viewPath the path used to get the appropriate populator.
     */
    public static void populateFormAndViewVariables(final javax.faces.context.FacesContext facesContext, Object form, String viewPath)
    {
        try
        {
            final String viewId = (viewPath != null && viewPath.trim().length() > 0) ? viewPath : getViewId(facesContext);
	        final Class<?> populator = populators.get(viewId);
	        if (populator != null)
	        {
	            final java.lang.reflect.Method method = populator.getMethod(
	                "populateFormAndViewVariables",
	                new Class[]{javax.faces.context.FacesContext.class, Object.class});
	            method.invoke(populator, new Object[]{facesContext, form});
	       }
	    }
	    catch (final Throwable throwable)
	    {
	    	throw new RuntimeException(throwable);
	    }
    }

    protected static String getViewId(final javax.faces.context.FacesContext facesContext)
    {
        javax.faces.component.UIViewRoot view  = facesContext.getViewRoot();
        return view != null ? view.getViewId() : null;
    }

    /**
     * Stores the view populators by path.
     */
    private static final java.util.Map<String, Class<?>> populators = new java.util.HashMap<String, Class<?>>();

    static
    {
        populators.put("/org/andromda/cartridges/jsf/tests/duplicateactions/show-something.xhtml", org.andromda.cartridges.jsf.tests.duplicateactions.ShowSomethingPopulator.class);
        populators.put("/org/andromda/cartridges/jsf/tests/duplicateactions/show-something.jsf", org.andromda.cartridges.jsf.tests.duplicateactions.ShowSomethingPopulator.class);
    }
}