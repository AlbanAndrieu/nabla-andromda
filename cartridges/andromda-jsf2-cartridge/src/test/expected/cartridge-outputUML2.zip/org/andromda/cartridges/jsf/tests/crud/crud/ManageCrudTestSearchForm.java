// license-header java merge-point
package org.andromda.cartridges.jsf.tests.crud.crud;

/**
 * This form holds the fields that are used in the search operation of CrudTest 
 *
 */
public final class ManageCrudTestSearchForm
    implements java.io.Serializable
{

    private java.lang.String stringAttribute;

    /**
     * 
     */
    public java.lang.String getStringAttribute()
    {
        return this.stringAttribute;
    }

    /**
     * 
     */
    public void setStringAttribute(java.lang.String stringAttribute)
    {
        this.stringAttribute = stringAttribute;
    }

    private java.lang.Integer intRequiredAttribute;

    /**
     * 
     */
    public java.lang.Integer getIntRequiredAttribute()
    {
        return this.intRequiredAttribute;
    }

    /**
     * 
     */
    public void setIntRequiredAttribute(java.lang.Integer intRequiredAttribute)
    {
        this.intRequiredAttribute = intRequiredAttribute;
    }

    private java.lang.Long id;

    /**
     * 
     */
    public java.lang.Long getId()
    {
        return this.id;
    }

    /**
     * 
     */
    public void setId(java.lang.Long id)
    {
        this.id = id;
    }


    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -6625796159769866884L;
}