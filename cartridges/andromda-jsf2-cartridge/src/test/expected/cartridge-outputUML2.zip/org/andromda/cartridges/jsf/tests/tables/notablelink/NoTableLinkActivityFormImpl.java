// license-header java merge-point
package org.andromda.cartridges.jsf.tests.tables.notablelink;

/**
 * 
 */
public class NoTableLinkActivityFormImpl
    implements java.io.Serializable
{
    public NoTableLinkActivityFormImpl()
    {
        final java.text.DateFormat customTablesThreeDateFormatter = new java.text.SimpleDateFormat("dd/MMM/yy");
        customTablesThreeDateFormatter.setLenient(true);
        this.dateTimeFormatters.put("customTables.three", customTablesThreeDateFormatter);
        // - setup the default java.util.Date.toString() formatter
        final java.text.DateFormat dateFormatter = new java.text.SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private transient javax.faces.event.FacesEvent event;

    public void setEvent(javax.faces.event.FacesEvent event)
    {
        this.event = event;
    }

    public javax.faces.event.ValueChangeEvent getValueChangeEvent()
    {
        return this.event instanceof javax.faces.event.ValueChangeEvent
            ? (javax.faces.event.ValueChangeEvent)this.event : null;
    }

    public javax.faces.event.ActionEvent getActionEvent()
    {
        return this.event instanceof javax.faces.event.ActionEvent
            ? (javax.faces.event.ActionEvent)this.event : null;
    }

    private java.util.Collection tableDatas;

    /**
     * 
     */
    public java.util.Collection getTableDatas()
    {
        return this.tableDatas;
    }

    /**
     * Keeps track of whether or not the value of tableDatas has
     * be populated at least once.
     */
    private boolean tableDatasSet = false;

    /**
     * Resets the value of the tableDatasSet to false
     */
    public void resetTableDatasSet()
    {
        this.tableDatasSet = false;
    }

    /**
     * Indicates whether or not the value for tableDatas has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTableDatasSet()
    {
        return this.tableDatasSet;
    }

    /**
     * 
     */
    public void setTableDatas(java.util.Collection tableDatas)
    {
        this.tableDatas = tableDatas;
        this.tableDatasSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] tableDatasValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] tableDatasLabelList;
    public java.lang.Object[] getTableDatasBackingList()
    {
        java.lang.Object[] values = this.tableDatasValueList;
        java.lang.Object[] labels = this.tableDatasLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getTableDatasValueList()
    {
        return this.tableDatasValueList;
    }

    public void setTableDatasValueList(java.lang.Object[] tableDatasValueList)
    {
        this.tableDatasValueList = tableDatasValueList;
    }

    public java.lang.Object[] getTableDatasLabelList()
    {
        return this.tableDatasLabelList;
    }

    public void setTableDatasLabelList(java.lang.Object[] tableDatasLabelList)
    {
        this.tableDatasLabelList = tableDatasLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setTableDatasBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.tableDatasValueList = null;
        this.tableDatasLabelList = null;
        if (items != null)
        {
            this.tableDatasValueList = new java.lang.Object[items.size()];
            this.tableDatasLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.tableDatasValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.tableDatasLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.tableDatasLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    private java.util.Collection tableDatasBackingValue;

    public void setTableDatasBackingValue(java.util.Collection tableDatasBackingValue)
    {
        this.tableDatasBackingValue = tableDatasBackingValue;
    }

    public java.util.Collection getTableDatasBackingValue()
    {
        return this.tableDatasBackingValue;
    }


    private org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow[] customTables;

    /**
     * 
     */
    public org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow[] getCustomTables()
    {
        return this.customTables;
    }

    /**
     * Keeps track of whether or not the value of customTables has
     * be populated at least once.
     */
    private boolean customTablesSet = false;

    /**
     * Resets the value of the customTablesSet to false
     */
    public void resetCustomTablesSet()
    {
        this.customTablesSet = false;
    }

    /**
     * Indicates whether or not the value for customTables has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isCustomTablesSet()
    {
        return this.customTablesSet;
    }

    /**
     * 
     */
    public void setCustomTables(org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow[] customTables)
    {
        this.customTables = customTables;
        this.customTablesSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] customTablesValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] customTablesLabelList;
    public java.lang.Object[] getCustomTablesBackingList()
    {
        java.lang.Object[] values = this.customTablesValueList;
        java.lang.Object[] labels = this.customTablesLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getCustomTablesValueList()
    {
        return this.customTablesValueList;
    }

    public void setCustomTablesValueList(java.lang.Object[] customTablesValueList)
    {
        this.customTablesValueList = customTablesValueList;
    }

    public java.lang.Object[] getCustomTablesLabelList()
    {
        return this.customTablesLabelList;
    }

    public void setCustomTablesLabelList(java.lang.Object[] customTablesLabelList)
    {
        this.customTablesLabelList = customTablesLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setCustomTablesBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.customTablesValueList = null;
        this.customTablesLabelList = null;
        if (items != null)
        {
            this.customTablesValueList = new java.lang.Object[items.size()];
            this.customTablesLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.customTablesValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.customTablesLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.customTablesLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    private org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow[] customTablesBackingValue;

    public void setCustomTablesBackingValue(org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow[] customTablesBackingValue)
    {
        this.customTablesBackingValue = customTablesBackingValue;
    }

    public org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow[] getCustomTablesBackingValue()
    {
        return this.customTablesBackingValue;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] customTablesOneValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] customTablesOneLabelList;
    public java.lang.Object[] getCustomTablesOneBackingList()
    {
        java.lang.Object[] values = this.customTablesOneValueList;
        java.lang.Object[] labels = this.customTablesOneLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getCustomTablesOneValueList()
    {
        return this.customTablesOneValueList;
    }

    public void setCustomTablesOneValueList(java.lang.Object[] customTablesOneValueList)
    {
        this.customTablesOneValueList = customTablesOneValueList;
    }

    public java.lang.Object[] getCustomTablesOneLabelList()
    {
        return this.customTablesOneLabelList;
    }

    public void setCustomTablesOneLabelList(java.lang.Object[] customTablesOneLabelList)
    {
        this.customTablesOneLabelList = customTablesOneLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setCustomTablesOneBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.customTablesOneValueList = null;
        this.customTablesOneLabelList = null;
        if (items != null)
        {
            this.customTablesOneValueList = new java.lang.Object[items.size()];
            this.customTablesOneLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.customTablesOneValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.customTablesOneLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.customTablesOneLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] customTablesTwoValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] customTablesTwoLabelList;
    public java.lang.Object[] getCustomTablesTwoBackingList()
    {
        java.lang.Object[] values = this.customTablesTwoValueList;
        java.lang.Object[] labels = this.customTablesTwoLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getCustomTablesTwoValueList()
    {
        return this.customTablesTwoValueList;
    }

    public void setCustomTablesTwoValueList(java.lang.Object[] customTablesTwoValueList)
    {
        this.customTablesTwoValueList = customTablesTwoValueList;
    }

    public java.lang.Object[] getCustomTablesTwoLabelList()
    {
        return this.customTablesTwoLabelList;
    }

    public void setCustomTablesTwoLabelList(java.lang.Object[] customTablesTwoLabelList)
    {
        this.customTablesTwoLabelList = customTablesTwoLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setCustomTablesTwoBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.customTablesTwoValueList = null;
        this.customTablesTwoLabelList = null;
        if (items != null)
        {
            this.customTablesTwoValueList = new java.lang.Object[items.size()];
            this.customTablesTwoLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.customTablesTwoValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.customTablesTwoLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.customTablesTwoLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] customTablesThreeValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] customTablesThreeLabelList;
    public java.lang.Object[] getCustomTablesThreeBackingList()
    {
        java.lang.Object[] values = this.customTablesThreeValueList;
        java.lang.Object[] labels = this.customTablesThreeLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getCustomTablesThreeValueList()
    {
        return this.customTablesThreeValueList;
    }

    public void setCustomTablesThreeValueList(java.lang.Object[] customTablesThreeValueList)
    {
        this.customTablesThreeValueList = customTablesThreeValueList;
    }

    public java.lang.Object[] getCustomTablesThreeLabelList()
    {
        return this.customTablesThreeLabelList;
    }

    public void setCustomTablesThreeLabelList(java.lang.Object[] customTablesThreeLabelList)
    {
        this.customTablesThreeLabelList = customTablesThreeLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setCustomTablesThreeBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.customTablesThreeValueList = null;
        this.customTablesThreeLabelList = null;
        if (items != null)
        {
            this.customTablesThreeValueList = new java.lang.Object[items.size()];
            this.customTablesThreeLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.customTablesThreeValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.customTablesThreeLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.customTablesThreeLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] customTablesNoColumnForThisAttributeValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] customTablesNoColumnForThisAttributeLabelList;
    public java.lang.Object[] getCustomTablesNoColumnForThisAttributeBackingList()
    {
        java.lang.Object[] values = this.customTablesNoColumnForThisAttributeValueList;
        java.lang.Object[] labels = this.customTablesNoColumnForThisAttributeLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getCustomTablesNoColumnForThisAttributeValueList()
    {
        return this.customTablesNoColumnForThisAttributeValueList;
    }

    public void setCustomTablesNoColumnForThisAttributeValueList(java.lang.Object[] customTablesNoColumnForThisAttributeValueList)
    {
        this.customTablesNoColumnForThisAttributeValueList = customTablesNoColumnForThisAttributeValueList;
    }

    public java.lang.Object[] getCustomTablesNoColumnForThisAttributeLabelList()
    {
        return this.customTablesNoColumnForThisAttributeLabelList;
    }

    public void setCustomTablesNoColumnForThisAttributeLabelList(java.lang.Object[] customTablesNoColumnForThisAttributeLabelList)
    {
        this.customTablesNoColumnForThisAttributeLabelList = customTablesNoColumnForThisAttributeLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setCustomTablesNoColumnForThisAttributeBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.customTablesNoColumnForThisAttributeValueList = null;
        this.customTablesNoColumnForThisAttributeLabelList = null;
        if (items != null)
        {
            this.customTablesNoColumnForThisAttributeValueList = new java.lang.Object[items.size()];
            this.customTablesNoColumnForThisAttributeLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.customTablesNoColumnForThisAttributeValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.customTablesNoColumnForThisAttributeLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.customTablesNoColumnForThisAttributeLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    /**
     * Resets all the "isSet" flags.
     */
     public void resetIsSetFlags()
     {
         this.resetTableDatasSet();
         this.resetCustomTablesSet();
     }

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map<java.lang.String, java.text.DateFormat> dateTimeFormatters =
        new java.util.HashMap<java.lang.String, java.text.DateFormat>();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map<java.lang.String, java.text.DateFormat> getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private transient java.util.Map<java.lang.String, javax.faces.application.FacesMessage> jsfMessages =
        new java.util.LinkedHashMap<java.lang.String, javax.faces.application.FacesMessage>();


    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(javax.faces.application.FacesMessage jsfMessage)
    {
        if (this.jsfMessages != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public java.util.Collection<javax.faces.application.FacesMessage> getJsfMessages()
    {
        if (this.jsfMessages == null)
        {
            this.jsfMessages = new java.util.LinkedHashMap<java.lang.String, javax.faces.application.FacesMessage>();
        }
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final java.util.Collection<javax.faces.application.FacesMessage> messages)
    {
        if (messages != null)
        {
            for (final java.util.Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                javax.faces.application.FacesMessage jsfMessage = (javax.faces.application.FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The faces message title (used on a view).
     */
    private String jsfMessagesTitle;

    /**
     * The optional faces message title to set (used on a view).  If not set, the default title
     * will be used.
     *
     * @param jsfMessagesTitle the title to use for the messages on the view.
     */
    public void setJsfMessagesTitle(final String jsfMessagesTitle)
    {
        this.jsfMessagesTitle = jsfMessagesTitle;
    }

    /**
     * Gets the faces messages title to use.
     *
     * @return the faces messages title.
     */
    public String getJsfMessagesTitle()
    {
        return this.jsfMessagesTitle;
    }

    /**
     * Gets the maximum severity of the messages stored in this form.
     *
     * @return the maximum severity or null if no messages are present and/or severity isn't set.
     */
    public javax.faces.application.FacesMessage.Severity getMaximumMessageSeverity()
    {
        javax.faces.application.FacesMessage.Severity maxSeverity = null;
        for (final javax.faces.application.FacesMessage message : this.getJsfMessages())
        {
            final javax.faces.application.FacesMessage.Severity severity = message.getSeverity();
            if (maxSeverity == null || (severity != null && severity.getOrdinal() > maxSeverity.getOrdinal()))
            {
                maxSeverity = severity;
            }
        }
        return maxSeverity;
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 8406701110595000677L;
}
