/* --------------- Many2ManyTwo table definition --------------------- */
CREATE TABLE MANY2_MANY_TWO 
(
    ID NUMBER(19) NOT NULL,
    ENTITY_SEVEN_FK NUMBER(19) NULL
);

/* ------------- relation indexes ------------------ */
CREATE INDEX IDXENTITYSEVENMANY2MANYTWO ON MANY2_MANY_TWO
(
       ENTITY_SEVEN_FK
);


/* ------------ primary key contraints ---------------- */
ALTER TABLE MANY2_MANY_TWO
   ADD  ( CONSTRAINT XPKMANY2MANYTWO PRIMARY KEY (ID) );
