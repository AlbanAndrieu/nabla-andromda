/* --------------- EntityThree table definition --------------------- */
CREATE TABLE ENTITY_THREE 
(
    ID NUMBER(19) NOT NULL,
    TEST_ATTRIBUTE NUMBER(1) NULL,
    TEST_ATTRIBUTE_TWO NUMBER(19) NULL,
    ENTITY_FOUR_FK NUMBER(19) NOT NULL
);

/* ------------- relation indexes ------------------ */
CREATE INDEX IDXENTITYFOURENTITYTHREE ON ENTITY_THREE
(
       ENTITY_FOUR_FK
);


/* ------------ primary key contraints ---------------- */
ALTER TABLE ENTITY_THREE
   ADD  ( CONSTRAINT XPKENTITYTHREE PRIMARY KEY (ID) );
